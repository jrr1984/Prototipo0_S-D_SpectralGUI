# -*- coding: utf-8 -*-
# Copyright 2016 Chris Rogers
"""
Package containing drivers for lock-in amplifiers.
"""
from .. import Instrument


class Lockin(Instrument):
    pass


