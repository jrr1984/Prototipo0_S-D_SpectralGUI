# -*- coding: utf-8 -*-
# Copyright 2016 Chris Rogers
"""
Package containing drivers for motion control devices.
"""
from .. import Instrument


class Motion(Instrument):
    pass


