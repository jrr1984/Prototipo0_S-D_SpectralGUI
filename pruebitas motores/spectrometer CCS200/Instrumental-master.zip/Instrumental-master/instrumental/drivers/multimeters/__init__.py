from .. import Instrument

class Multimeter(Instrument):
    pass
