# -*- coding: utf-8 -*-
# Copyright 2014 Chris Rogers, Nate Bogdanowicz
"""
Package containing drivers for power meters.
"""
from .. import Instrument


class PowerMeter(Instrument):
    pass
