# -*- coding: utf-8 -*-
# Copyright 2014 Nate Bogdanowicz
"""
Package containing drivers for wavemeters.
"""
from .. import Instrument


class Wavemeter(Instrument):
    pass
