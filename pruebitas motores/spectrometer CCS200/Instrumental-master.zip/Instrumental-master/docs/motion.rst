Motion Control
==============

Create :py:class:`~instrumental.drivers.motion.Motion` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    filter-flipper
    motion-kinesis
    tdc-001
    ecc100
