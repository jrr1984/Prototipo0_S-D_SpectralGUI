Plotting
========

.. automodule:: instrumental.plotting
    :members:
