Thorlabs CCS Spectrometers
==========================

.. toctree::

This module is for controlling Thorlabs CCS spectrometers.


Installation
------------
The Thorlabs OSA software provided on Thorlabs website must be installed.
This driver is currently windows only.

Module Reference
----------------

.. automodule:: instrumental.drivers.spectrometers.thorlabs_ccs
    :members:
    :undoc-members:
