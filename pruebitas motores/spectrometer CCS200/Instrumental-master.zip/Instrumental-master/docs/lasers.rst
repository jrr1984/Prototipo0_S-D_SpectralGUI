Lasers
======

Create :py:class:`~instrumental.drivers.lasers.Laser` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    femto-ferb
