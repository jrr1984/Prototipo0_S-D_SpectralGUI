Wavemeters
==========

Create :py:class:`~instrumental.drivers.wavemeters.Wavemeter` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1
     
    burleigh-wavemeters
