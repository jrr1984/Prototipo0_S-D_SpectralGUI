Fitting
=======

.. automodule:: instrumental.fitting
    :members:
