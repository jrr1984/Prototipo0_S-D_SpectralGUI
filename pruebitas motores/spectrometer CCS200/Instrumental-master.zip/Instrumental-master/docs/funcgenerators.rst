Function Generators
===================

Create :py:class:`~instrumental.drivers.funcgenerators.FunctionGenerator` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    tek-funcgens
