Scopes
======

Create :py:class:`~instrumental.drivers.scopes.Scope` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    tek-scopes
