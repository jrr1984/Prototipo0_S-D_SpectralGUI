Lock-in Amplifiers
==================

Create :py:class:`~instrumental.drivers.lockins.Lockin` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    sr850
