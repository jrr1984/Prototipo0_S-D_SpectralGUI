DAQs
====

Create :py:class:`~instrumental.drivers.daq.DAQ` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    ni-daqs
