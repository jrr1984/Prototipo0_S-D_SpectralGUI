Multimeters
===========

Create :py:class:`~instrumental.drivers.multimeters.Multimeter` objects using :py:func:`~instrumental.drivers.instrument`.


.. toctree::
    :maxdepth: 1

    multimeters-hp
